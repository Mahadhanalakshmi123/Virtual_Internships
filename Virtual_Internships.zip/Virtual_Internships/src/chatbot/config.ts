import { createChatBotMessage } from 'react-chatbot-kit';

const config = {
  botName: 'InternshipHelperBot',
  initialMessages: [
    createChatBotMessage(
      "Hi! I can help you prepare for interviews or learn more about internships. Ask me anything!"
    ),
  ],
  customStyles: {
    botMessageBox: {
      backgroundColor: '#3b82f6',
    },
    chatButton: {
      backgroundColor: '#2563eb',
    },
  },
};

export default config;

class ActionProvider {
    createChatBotMessage: any;
    setState: any;
  
    constructor(createChatBotMessage: any, setStateFunc: any) {
      this.createChatBotMessage = createChatBotMessage;
      this.setState = setStateFunc;
    }
  
    handleInterviewPrep = () => {
      const message = this.createChatBotMessage(
        'Here are some tips to prepare for your internship interview:\n- Research the company\n- Practice common questions\n- Highlight your skills'
      );
      this.setState((prev: any) => ({
        ...prev,
        messages: [...prev.messages, message],
      }));
    };
  
    handleInternshipInfo = () => {
      const message = this.createChatBotMessage(
        'This internship involves working with top companies. Learn more on LinkedIn or Indeed.'
      );
      this.setState((prev: any) => ({
        ...prev,
        messages: [...prev.messages, message],
      }));
    };
  
    handleUnknownMessage = () => {
      const message = this.createChatBotMessage(
        'Sorry, I didn’t understand that. Can you try asking differently?'
      );
      this.setState((prev: any) => ({
        ...prev,
        messages: [...prev.messages, message],
      }));
    };
  }
  
  export default ActionProvider;
  
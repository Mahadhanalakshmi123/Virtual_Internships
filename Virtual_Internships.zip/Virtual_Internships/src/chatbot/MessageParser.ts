class MessageParser {
    actionProvider: any;
  
    constructor(actionProvider: any) {
      this.actionProvider = actionProvider;
    }
  
    parse(message: string) {
      if (message.includes('interview')) {
        this.actionProvider.handleInterviewPrep();
      } else if (message.includes('internship')) {
        this.actionProvider.handleInternshipInfo();
      } else {
        this.actionProvider.handleUnknownMessage();
      }
    }
  }
  
  export default MessageParser;
  
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Send, ArrowLeft } from 'lucide-react';

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  skills: string;
  resume: File | null;
}

export default function SkillsAndResume() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    skills: '',
    resume: null
  });

  useEffect(() => {
    // Retrieve personal info from localStorage
    const personalInfo = localStorage.getItem('personalInfo');
    if (personalInfo) {
      setFormData(prev => ({
        ...prev,
        ...JSON.parse(personalInfo)
      }));
    } else {
      // If no personal info is found, redirect back to first page
      navigate('/');
    }
  }, [navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log("file uploaded")
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({
        ...prev,
        resume: e.target.files![0]
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    try {
      const form = document.getElementById('resumeForm') as HTMLFormElement;
      const localForm = new FormData(form);
      const response = await fetch('http://localhost:5000/predict', {
        method: 'POST',
        body: localForm,
      });
  
      if (!response.ok) {
        console.error('Network response was not ok');
        return;
      }
  
      const data = await response.json();
      localStorage.setItem('Data', JSON.stringify(data));
      localStorage.setItem('personalInfo', JSON.stringify(formData));
  
      console.log('Data successfully saved. Navigating to /matching');
      navigate('/matching'); // Ensure this matches your route definition
    } catch (error) {
      console.error('Error during form submission:', error);
    }
  };
  

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
          <h2 className="text-2xl font-semibold text-white">Skills & Resume</h2>
          <p className="text-blue-100 mt-1">Step 2 of 2</p>
        </div>
        
        <form id="resumeForm" onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label htmlFor="skills" className="block text-sm font-medium text-gray-700 mb-1">
              Skills Description
            </label>
            <textarea
              id="skills"
              name="skills"
              required
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150"
              value={formData.skills}
              onChange={handleInputChange}
              placeholder="Describe your relevant skills, experience, and why you'd be a great fit for this internship..."
            />
          </div>

          <div>
            <label htmlFor="resume" className="block text-sm font-medium text-gray-700 mb-1">
              Resume Upload
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg hover:border-blue-400 transition-colors duration-150">
              <div className="space-y-2 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label htmlFor="resume" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                    <span>Upload a file</span>
                    <input
                      id="resume"
                      name="resume"
                      type="file"
                      className="sr-only"
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileChange}
                      required
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">PDF, DOC, DOCX up to 10MB</p>
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="flex-1 flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Back
            </button>
            
            <button
              type="submit"
              className="flex-1 flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150"
            >
              Find Matching Internships
              <Send className="ml-2 h-5 w-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
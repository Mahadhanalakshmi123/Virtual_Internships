import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Briefcase, Star, ArrowLeft } from "lucide-react";
import ChatBotComponent from './ChatBotComponent';  // Importing the chatbot component

interface Internship {
  id: number;
  title: string;
  company: string;
  description: string;
  requiredSkills: string[];
  matchScore: number;
}

// Simple ML scoring function to match skills
const calculateMatchScore = (
  userSkills: string,
  internshipSkills: string[]
): number => {
  const userSkillsArray = userSkills.toLowerCase().split(/[,.\s]+/);
  const matches = internshipSkills.filter((skill) =>
    userSkillsArray.some(
      (userSkill) =>
        userSkill.length > 2 && skill.toLowerCase().includes(userSkill)
    )
  );
  return (matches.length / internshipSkills.length) * 100;
};

export default function InternshipMatching() {
  const navigate = useNavigate();
  const [userSkills, setUserSkills] = useState("");
  const [matchedInternships, setMatchedInternships] = useState<Internship[]>([]);
  const [avilableInterns, setAvilableInterns] = useState([]);
  const [showChatBot, setShowChatBot] = useState(false);  // State for toggling chatbot

  // Mock internship data - in a real app, this would come from an API
  const availableInternships: Internship[] = [
    {
      id: 1,
      title: "Software Development Intern",
      company: "TechCorp",
      description:
        "Join our team to work on cutting-edge web applications using React and TypeScript.",
      requiredSkills: ["React", "TypeScript", "JavaScript", "Web Development"],
      matchScore: 0,
    },
    {
      id: 2,
      title: "Data Science Intern",
      company: "DataTech",
      description:
        "Work with big data and machine learning models to solve real-world problems.",
      requiredSkills: [
        "Python",
        "Machine Learning",
        "Data Analysis",
        "Statistics",
      ],
      matchScore: 0,
    },
    {
      id: 3,
      title: "Frontend Development Intern",
      company: "WebSolutions",
      description:
        "Create beautiful and responsive user interfaces using modern web technologies.",
      requiredSkills: ["HTML", "CSS", "JavaScript", "React", "UI/UX"],
      matchScore: 0,
    },
  ];

  useEffect(() => {
    // Retrieve skills from localStorage
    const internShips = localStorage.getItem("Data") || "";
    console.log(internShips || "{}");
    const personalInfo = localStorage.getItem("personalInfo");
    setAvilableInterns(JSON.parse(internShips));
    if (personalInfo) {
      const { skills } = JSON.parse(personalInfo);
      setUserSkills(skills.split(","));

      // Calculate match scores and sort internships
      const scoredInternships = availableInternships
        .map((internship) => ({
          ...internship,
          matchScore: calculateMatchScore(skills, internship.requiredSkills),
        }))
        .sort((a, b) => b.matchScore - a.matchScore);

      setMatchedInternships(scoredInternships);
    } else {
      navigate("/");
    }
  }, [navigate]);

  // Toggle the chatbot visibility
  const toggleChatBot = () => {
    setShowChatBot(!showChatBot);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
          <h2 className="text-2xl font-semibold text-white">Matching Internships</h2>
          <p className="text-blue-100 mt-1">Based on your skills</p>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid gap-6">
            {avilableInterns?.matched_internships?.map((internship, index) => (
              <div
                key={index}
                className="border rounded-lg p-6 hover:shadow-lg transition-shadow duration-200"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 flex items-center">
                      <Briefcase className="h-5 w-5 mr-2 text-blue-600" />
                      {internship.Internship}
                    </h3>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-400 mr-1" />
                    {/* <span className="font-semibold">{Math.round(internship.matchScore)}% Match</span> */}
                  </div>
                </div>

                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">
                    Required Skills:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {userSkills?.map((skill, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="gap-2 flex">
                  {" "}
                  <a
                    href={internship?.LinkedIn_URL}
                    className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-300 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Apply Now on LinkedIn
                  </a>

                  <a
                    href={internship?.Indeed_Link}
                    className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Apply Now on Indeed
                  </a>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6">
            <button
              onClick={() => navigate("/skills-resume")}
              className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Back to Application
            </button>
          </div>

          {/* Chatbot Button */}
          <div className="mt-6">
            <button
              onClick={toggleChatBot}
              className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Chat with Us
            </button>
          </div>
          
          {/* Chatbot Component */}
          {showChatBot && <ChatBotComponent />}
        </div>
      </div>
    </div>
  );
}

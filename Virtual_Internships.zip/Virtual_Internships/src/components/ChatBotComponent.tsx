import React, { useState } from 'react';

const GEMINI_API_KEY = 'AIzaSyBzV-ZHz3sq5ayEAdAJ0f_qCoY02QMLUlg'; // Replace with your Gemini API key

const ChatBotComponent: React.FC = () => {
  const [showChat, setShowChat] = useState(false);
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<string[]>([]);

  // Toggle chat visibility
  const toggleChat = () => {
    setShowChat(!showChat);
  };

  // Handle user input message
  const handleUserMessage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setMessage(event.target.value);
  };

  // Handle send message action
  const handleSendMessage = async () => {
    if (message.trim() === '') return;

    // Add the user message to chat history
    setChatHistory((prevHistory) => [...prevHistory, `You: ${message}`]);

    try {
      // Make a request to the Gemini API instead of OpenAI
      const response = await fetch('https://gemini.googleapis.com/v1/generativeAI/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${GEMINI_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'gemini-2.0-flash-exp', // Update with the Gemini model you're using
          generationConfig: {
            temperature: 1,
            topP: 0.95,
            topK: 40,
            maxOutputTokens: 8192,
            responseMimeType: 'application/json',
          },
          history: [
            // Include chat history if needed
          ],
          messages: [
            { role: 'user', content: message }
          ],
        }),
      });

      const data = await response.json();
      const botReply = data.choices[0].message.content.trim(); // Adjust based on the Gemini API response format

      // Add bot reply to chat history
      setChatHistory((prevHistory) => [...prevHistory, `Bot: ${botReply}`]);
    } catch (error) {
      console.error('Error fetching response:', error);
      setChatHistory((prevHistory) => [
        ...prevHistory,
        'Bot: Sorry, something went wrong. Please try again.',
      ]);
    }

    // Clear the input message field
    setMessage('');
  };

  return (
    <div>
      {/* Toggle button to show or hide the chat */}
      <button
        onClick={toggleChat}
        className="fixed bottom-5 right-5 bg-indigo-600 text-white py-2 px-4 rounded shadow-lg hover:bg-indigo-500"
      >
        {showChat ? 'Close Chat' : 'Chat with Us'}
      </button>

      {/* Only show the chat interface if `showChat` is true */}
      {showChat && (
        <div className="fixed bottom-16 right-5 w-80 bg-white shadow-lg rounded-md border">
          <div className="chat-box p-4 max-h-80 overflow-y-auto">
            {chatHistory.map((msg, index) => (
              <p key={index} className="mb-2">
                {msg}
              </p>
            ))}
          </div>

          {/* Input field to type messages */}
          <div className="input-box p-2 border-t">
            <input
              type="text"
              value={message}
              onChange={handleUserMessage}
              placeholder="Ask me about internships..."
              className="w-full p-2 border border-gray-300 rounded"
            />
            <button
              onClick={handleSendMessage}
              className="mt-2 w-full bg-indigo-600 text-white py-2 rounded"
            >
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatBotComponent;
